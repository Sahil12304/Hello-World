from flask import Flask, Markup, render_template
import requests
import json

app = Flask(__name__)
file = open('data.json')
data = json.load(file)
clustered_labels = []
for x in data['Worksheet']:
    if x not in clustered_labels:
        clustered_labels.append(x['category'])
filtered_clustered_labels = set(clustered_labels)
clustered_labels = list(filtered_clustered_labels)
labels = clustered_labels

clustered_list = []
for x in labels:
    price = 0
    for i in data['Worksheet']:
        if i['category'] == x:
            price = price + float(i['sale_price'])
    clustered_list.append(price)
print(clustered_list)

values = clustered_list
#
#
# colors = [
#     "rgb(205, 92, 92)", "#46BFBD", "#FDB45C", "#FEDCBA",
#     "#ABCDEF", "#DDDDDD", "#ABCABC", "#4169E1",
#     "#C71585", "#FF4500", "#FEDCBA", "#46BFBD"]
#
# @app.route('/bar')
# def bar():
#     bar_labels=labels
#     bar_values=values
#     return render_template('bar_chart.html', title='Big Basket Sales Price Per Category', max=3000, labels=bar_labels, values=bar_values)
#
# @app.route('/line')
# def line():
#     line_labels=labels
#     line_values=values
#     return render_template('line_chart.html', title='Reviews Per Category', max=17000, labels=line_labels, values=line_values)
#
# @app.route('/pie')
# def pie():
#     pie_labels = labels
#     pie_values = values
#     return render_template('pie_chart.html', title='Bitcoin Monthly Price in USD', max=17000, set=zip(values, labels, colors))
#
# @app.route('/demo')
# def good():
#     return render_template('demo.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)



x